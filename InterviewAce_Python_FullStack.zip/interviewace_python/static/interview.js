const buttons = document.querySelectorAll(".q-btn");
const questionEl = document.getElementById("question");
const companyEl = document.getElementById("company");
const answerEl = document.getElementById("answer");
const resultEl = document.getElementById("result");
let selectedId = Number(buttons[0]?.dataset.id || 1);
let recognition = null;
let listening = false;

buttons.forEach(btn => {
  btn.addEventListener("click", () => {
    buttons.forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    selectedId = Number(btn.dataset.id);
    questionEl.textContent = btn.dataset.question;
    companyEl.textContent = btn.dataset.company;
    answerEl.value = "";
    resultEl.classList.add("hidden");
  });
});

document.getElementById("speakQuestion")?.addEventListener("click", () => {
  const utterance = new SpeechSynthesisUtterance(questionEl.textContent);
  utterance.rate = 1;
  speechSynthesis.cancel();
  speechSynthesis.speak(utterance);
});

document.getElementById("micBtn")?.addEventListener("click", () => {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  const status = document.getElementById("speechStatus");
  if (!SpeechRecognition) {
    status.textContent = "Speech recognition is not supported in this browser. Please type your answer.";
    return;
  }
  if (listening) {
    recognition.stop();
    return;
  }
  recognition = new SpeechRecognition();
  recognition.continuous = true;
  recognition.interimResults = true;
  recognition.lang = "en-US";
  let finalText = answerEl.value ? answerEl.value + " " : "";
  recognition.onstart = () => {
    listening = true;
    document.getElementById("micBtn").textContent = "⏹️ Stop Speaking";
    status.textContent = "Listening...";
  };
  recognition.onresult = (event) => {
    let interim = "";
    for (let i = event.resultIndex; i < event.results.length; i++) {
      const text = event.results[i][0].transcript;
      if (event.results[i].isFinal) finalText += text + " ";
      else interim += text;
    }
    answerEl.value = (finalText + interim).trim();
  };
  recognition.onerror = (event) => {
    status.textContent = "Microphone error: " + event.error;
  };
  recognition.onend = () => {
    listening = false;
    document.getElementById("micBtn").textContent = "🎙️ Start Speaking";
    status.textContent = "Speech input stopped.";
  };
  recognition.start();
});

document.getElementById("evaluateBtn")?.addEventListener("click", async () => {
  const answer = answerEl.value.trim();
  if (!answer) {
    alert("Please type or speak your answer first.");
    return;
  }
  const button = document.getElementById("evaluateBtn");
  button.disabled = true;
  button.textContent = "Evaluating...";
  try {
    const response = await fetch("/api/evaluate", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({question_id: selectedId, answer})
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Evaluation failed");
    document.getElementById("score").textContent = data.score + "%";
    document.getElementById("feedback").textContent = data.feedback;
    document.getElementById("matched").textContent = data.matched.length ? data.matched.join(", ") : "None";
    document.getElementById("missing").textContent = data.missing.length ? data.missing.join(", ") : "None";
    resultEl.classList.remove("hidden");
  } catch (err) {
    alert(err.message);
  } finally {
    button.disabled = false;
    button.textContent = "Evaluate Answer";
  }
});
