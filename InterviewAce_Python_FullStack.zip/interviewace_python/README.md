# InterviewAce - Python Full-Stack Version

This version converts the supplied InterviewAce architecture from Express/Node.js into a Python Flask full-stack application. The supplied specification calls for authentication, dashboard, mock interviews, speech processing, skill assessment, resume builder, job tracking and peer/learning features. This implementation includes the core student-facing features in one runnable Python project. fileciteturn0file0L436-L474

## Included

- Sign Up
- Sign In
- Logout
- SQLite database with persistent user data
- Password hashing
- Protected dashboard
- Mock interview questions
- Browser speech-to-text
- Browser text-to-speech
- Keyword-based answer evaluation
- Skill assessment quiz
- Job application tracker
- Resume builder
- Profile page
- Responsive frontend
- REST API endpoints for evaluation and health checks

## Run in VS Code on Windows

```powershell
cd interviewace_python
py -m venv venv
venv\Scripts\python.exe -m pip install -r requirements.txt
venv\Scripts\python.exe app.py
```

Then open:

http://127.0.0.1:5000

If PowerShell blocks `Activate.ps1`, you do NOT need to activate the environment. The commands above use the virtual environment's Python directly.

## Important

The database file `interviewace.db` is created automatically the first time the app starts.

For deployment, set a strong `SECRET_KEY` environment variable and use a production WSGI server such as Waitress or Gunicorn instead of Flask debug mode.

The browser speech feature uses the Web Speech API. If the browser does not support it, users can still type their answers.
