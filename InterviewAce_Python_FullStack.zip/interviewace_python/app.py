from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
from functools import wraps
from datetime import datetime
import os
import json

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "interviewace.db")

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "interviewace-dev-secret-change-me")
app.config["JSON_SORT_KEYS"] = False


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        branch TEXT DEFAULT 'Computer Science',
        created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS interview_results (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        question TEXT NOT NULL,
        answer TEXT NOT NULL,
        score INTEGER NOT NULL,
        feedback TEXT NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS jobs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        company TEXT NOT NULL,
        position TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'Applied',
        notes TEXT DEFAULT '',
        created_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS resumes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        full_name TEXT NOT NULL,
        phone TEXT DEFAULT '',
        education TEXT DEFAULT '',
        skills TEXT DEFAULT '',
        projects TEXT DEFAULT '',
        experience TEXT DEFAULT '',
        created_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS quiz_results (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        score INTEGER NOT NULL,
        total INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id)
    );
    """)
    conn.commit()
    conn.close()


QUESTIONS = [
    {
        "id": 1,
        "branch": "Computer Science",
        "company": "Amazon",
        "question": "How would you implement an LRU Cache with O(1) get and put operations?",
        "keywords": ["hashmap", "doubly linked list", "eviction", "constant time"]
    },
    {
        "id": 2,
        "branch": "Cybersecurity",
        "company": "General",
        "question": "What steps would you take to investigate a potential malware infection on an endpoint?",
        "keywords": ["isolation", "logs", "siem", "hash", "endpoint", "containment"]
    },
    {
        "id": 3,
        "branch": "IT",
        "company": "TCS",
        "question": "Explain the difference between a process and a thread.",
        "keywords": ["memory", "lightweight", "execution", "concurrency", "context switching"]
    },
    {
        "id": 4,
        "branch": "All",
        "company": "Amazon",
        "question": "Tell me about a project you completed under a tight deadline.",
        "keywords": ["planning", "prioritization", "milestones", "teamwork", "deadline"]
    },
    {
        "id": 5,
        "branch": "Computer Science",
        "company": "General",
        "question": "What is the difference between a stack and a queue?",
        "keywords": ["lifo", "fifo", "push", "pop", "enqueue", "dequeue"]
    }
]

QUIZ = [
    {"q": "Which data structure follows LIFO?", "options": ["Queue", "Stack", "Tree", "Graph"], "a": "Stack"},
    {"q": "Which language is commonly used for backend web development?", "options": ["Python", "HTML", "CSS", "XML"], "a": "Python"},
    {"q": "What does OOP stand for?", "options": ["Object Oriented Programming", "Open Online Protocol", "Object Output Process", "Order Of Processing"], "a": "Object Oriented Programming"},
    {"q": "Which SQL command is used to read data?", "options": ["GET", "SELECT", "READ", "OPEN"], "a": "SELECT"},
    {"q": "Which keyword creates a function in Python?", "options": ["func", "function", "def", "create"], "a": "def"},
]


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            if request.path.startswith("/api/"):
                return jsonify({"error": "Login required"}), 401
            flash("Please sign in first.", "warning")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def current_user():
    if "user_id" not in session:
        return None
    conn = get_db()
    user = conn.execute("SELECT id, name, email, branch FROM users WHERE id=?", (session["user_id"],)).fetchone()
    conn.close()
    return user


def evaluate_answer(question, answer):
    answer_low = (answer or "").lower()
    matched = [k for k in question["keywords"] if k.lower() in answer_low]
    missing = [k for k in question["keywords"] if k.lower() not in answer_low]
    score = round((len(matched) / len(question["keywords"])) * 100) if question["keywords"] else 0
    if score >= 75:
        feedback = "Excellent. Your answer covered most important concepts."
    elif score >= 40:
        feedback = "Good attempt. Add more technical keywords and explain your approach clearly."
    else:
        feedback = "Keep practicing. Review the core concepts and give a structured answer."
    return score, matched, missing, feedback


@app.context_processor
def inject_user():
    return {"logged_user": current_user()}


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        branch = request.form.get("branch", "Computer Science")
        if not name or not email or not password:
            flash("All fields are required.", "danger")
            return render_template("signup.html")
        if len(password) < 6:
            flash("Password must contain at least 6 characters.", "danger")
            return render_template("signup.html")
        conn = get_db()
        try:
            conn.execute(
                "INSERT INTO users(name,email,password,branch,created_at) VALUES(?,?,?,?,?)",
                (name, email, generate_password_hash(password), branch, datetime.now().isoformat())
            )
            conn.commit()
            flash("Account created successfully. Please sign in.", "success")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("An account with this email already exists.", "danger")
            return render_template("signup.html")
        finally:
            conn.close()
    return render_template("signup.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        conn = get_db()
        user = conn.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        conn.close()
        if user and check_password_hash(user["password"], password):
            session.clear()
            session["user_id"] = user["id"]
            session["user_name"] = user["name"]
            return redirect(url_for("dashboard"))
        flash("Invalid email or password.", "danger")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("home"))


@app.route("/dashboard")
@login_required
def dashboard():
    conn = get_db()
    uid = session["user_id"]
    interviews = conn.execute("SELECT * FROM interview_results WHERE user_id=? ORDER BY id DESC", (uid,)).fetchall()
    jobs = conn.execute("SELECT * FROM jobs WHERE user_id=? ORDER BY id DESC", (uid,)).fetchall()
    quizzes = conn.execute("SELECT * FROM quiz_results WHERE user_id=? ORDER BY id DESC", (uid,)).fetchall()
    conn.close()
    avg = round(sum(x["score"] for x in interviews) / len(interviews)) if interviews else 0
    return render_template("dashboard.html", interviews=interviews, jobs=jobs, quizzes=quizzes, avg=avg)


@app.route("/interview")
@login_required
def interview():
    return render_template("interview.html", questions=QUESTIONS)


@app.route("/api/evaluate", methods=["POST"])
@login_required
def api_evaluate():
    data = request.get_json(silent=True) or {}
    qid = int(data.get("question_id", 0))
    answer = data.get("answer", "").strip()
    question = next((q for q in QUESTIONS if q["id"] == qid), None)
    if not question:
        return jsonify({"error": "Question not found"}), 404
    if not answer:
        return jsonify({"error": "Please enter or speak an answer"}), 400

    score, matched, missing, feedback = evaluate_answer(question, answer)
    conn = get_db()
    conn.execute(
        "INSERT INTO interview_results(user_id,question,answer,score,feedback,created_at) VALUES(?,?,?,?,?,?)",
        (session["user_id"], question["question"], answer, score, feedback, datetime.now().isoformat())
    )
    conn.commit()
    conn.close()
    return jsonify({"score": score, "matched": matched, "missing": missing, "feedback": feedback})


@app.route("/skills", methods=["GET", "POST"])
@login_required
def skills():
    result = None
    if request.method == "POST":
        score = 0
        for i, item in enumerate(QUIZ):
            if request.form.get(f"q{i}") == item["a"]:
                score += 1
        conn = get_db()
        conn.execute(
            "INSERT INTO quiz_results(user_id,title,score,total,created_at) VALUES(?,?,?,?,?)",
            (session["user_id"], "Core Skills Quiz", score, len(QUIZ), datetime.now().isoformat())
        )
        conn.commit()
        conn.close()
        result = {"score": score, "total": len(QUIZ), "percentage": round(score / len(QUIZ) * 100)}
    return render_template("skills.html", quiz=QUIZ, result=result)


@app.route("/jobs", methods=["GET", "POST"])
@login_required
def jobs():
    conn = get_db()
    if request.method == "POST":
        company = request.form.get("company", "").strip()
        position = request.form.get("position", "").strip()
        status = request.form.get("status", "Applied")
        notes = request.form.get("notes", "").strip()
        if company and position:
            conn.execute(
                "INSERT INTO jobs(user_id,company,position,status,notes,created_at) VALUES(?,?,?,?,?,?)",
                (session["user_id"], company, position, status, notes, datetime.now().isoformat())
            )
            conn.commit()
            flash("Job application added.", "success")
        else:
            flash("Company and position are required.", "danger")
    rows = conn.execute("SELECT * FROM jobs WHERE user_id=? ORDER BY id DESC", (session["user_id"],)).fetchall()
    conn.close()
    return render_template("jobs.html", jobs=rows)


@app.route("/jobs/delete/<int:job_id>", methods=["POST"])
@login_required
def delete_job(job_id):
    conn = get_db()
    conn.execute("DELETE FROM jobs WHERE id=? AND user_id=?", (job_id, session["user_id"]))
    conn.commit()
    conn.close()
    return redirect(url_for("jobs"))


@app.route("/resume", methods=["GET", "POST"])
@login_required
def resume():
    saved = None
    conn = get_db()
    if request.method == "POST":
        data = {k: request.form.get(k, "").strip() for k in
                ["full_name", "phone", "education", "skills", "projects", "experience"]}
        if not data["full_name"]:
            flash("Full name is required.", "danger")
        else:
            conn.execute(
                "INSERT INTO resumes(user_id,full_name,phone,education,skills,projects,experience,created_at) VALUES(?,?,?,?,?,?,?,?)",
                (session["user_id"], data["full_name"], data["phone"], data["education"],
                 data["skills"], data["projects"], data["experience"], datetime.now().isoformat())
            )
            conn.commit()
            saved = data
            flash("Resume saved successfully.", "success")
    else:
        row = conn.execute("SELECT * FROM resumes WHERE user_id=? ORDER BY id DESC LIMIT 1", (session["user_id"],)).fetchone()
        if row:
            saved = dict(row)
    conn.close()
    return render_template("resume.html", saved=saved)


@app.route("/profile")
@login_required
def profile():
    return render_template("profile.html", user=current_user())


@app.route("/api/health")
def health():
    return jsonify({"status": "ok", "app": "InterviewAce", "time": datetime.now().isoformat()})


if __name__ == "__main__":
    init_db()
    app.run(host="127.0.0.1", port=5000, debug=True)
